# IMAGE PROCESSING APPLICATION
## Using OpenCV and PyQt5
### Install requiments: *pip install -r requirements.txt*
###
### Run app: Open terminal at folder "image-processing" and run command: *python app.py*
